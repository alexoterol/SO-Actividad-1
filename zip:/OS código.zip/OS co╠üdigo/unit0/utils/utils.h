
int random_uniform(int l);
std::vector<std::string> readAllStrings();

