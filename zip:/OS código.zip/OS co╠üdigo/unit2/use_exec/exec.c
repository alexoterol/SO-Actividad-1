//EXEC.c for called from execv call system
#include <stdio.h> 
#include <unistd.h> 
  
int main() 
{ 
    int i; 
    
    printf("I am EXEC.c called by execv() "); 
    printf("\n"); 
    return 0; 
}
