// C program to illustrate pipe system call in C
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#define STDIN 0
#define STDOUT 1

int main()
{
	int fd[2];
    pipe(fd);                         // create pipe
    if (fork() == 0) { //reads
		close(STDIN); //close stdin
		dup(fd[0]);  // redirect standard input to the pipe table
		close(fd[0]); // closed unused file descriptor
		close(fd[1]); // child does not write to pipe
		char *args[]={"/bin/cat",NULL};
		execv(args[0], args);
		exit(0);
	} else { //writes
       close(STDOUT); //close stdout
	   dup(fd[1]);  // redirect standard output to the pipe table;
       close(fd[0]); //parent does not read from pipe
       close(fd[1]); //closed unused file descriptor
	   char *args[]={"/bin/ps",NULL};
       execv(args[0], args);
       exit(0);
    }
}
